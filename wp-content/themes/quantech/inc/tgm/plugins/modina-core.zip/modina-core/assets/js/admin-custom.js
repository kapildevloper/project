
(function($) {
    "use strict";

    $(document).ready( function() {


    }); // end document ready function
})(jQuery); // End jQuery
